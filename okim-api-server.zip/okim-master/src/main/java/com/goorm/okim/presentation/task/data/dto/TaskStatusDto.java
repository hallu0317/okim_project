package com.goorm.okim.presentation.task.data.dto;

public class TaskStatusDto {
    private Long taskId;
    private String taskName;
    private boolean completed;
}