package com.goorm.okim.presentation.item;

public @interface OwnerOnlyCreate {
}
