package com.goorm.okim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OkimApplication {

	public static void main(String[] args) {
		SpringApplication.run(OkimApplication.class, args);
	}
}