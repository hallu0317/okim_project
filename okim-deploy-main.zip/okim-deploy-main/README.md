# okim-deploy
okim-deploy 레포지토리입니다.

배포 구조 api-server, auth-server, front로 총 3가지로 구성되어있습니다.


+api-server  
+--prod  
+auth-server  
+--prod  
+front  
+--prod  
